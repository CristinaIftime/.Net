﻿using Application.UseCases.Commands;
using Domain.Entities;
using Domain.Repositories;
using MediatR;


namespace Application.UseCases.CommandHandlers
{
    public class UpdateBookCommandHandler : IRequestHandler<UpdateBookCommand, bool>
    {
        private readonly IBookRepository bookRepository;

        public UpdateBookCommandHandler(IBookRepository bookRepository)
        {
            this.bookRepository = bookRepository;
        }

        public async Task<bool> Handle(UpdateBookCommand request, CancellationToken cancellationToken)
        {
            var book = await bookRepository.GetByIdAsync(request.Id);
            if (book == null)
            {
                return false; 
            }

            book.Title = request.Title;
            book.Author = request.Author;
            book.PublicationDate = request.PublicationDate;
            book.ISBN = request.ISBN;

            await bookRepository.UpdateAsync(book);
            return true;
        }
    }
}
